import type {
  ACCEPTED_MEDIA_TYPES,
  ESTIMATION_INPUT_MODES,
  MEDIA_TYPES,
  QUESTION_TYPES,
  QUIZZ_MODES,
  SCORING_MODES,
} from "@razzia/common/constants"

export type QuizzMode = (typeof QUIZZ_MODES)[keyof typeof QUIZZ_MODES]

export type QuestionType = (typeof QUESTION_TYPES)[keyof typeof QUESTION_TYPES]

export type ScoringMode = (typeof SCORING_MODES)[keyof typeof SCORING_MODES]

export interface MultiQuestionOptions {
  scoringMode: ScoringMode
}

export type EstimationInputMode =
  (typeof ESTIMATION_INPUT_MODES)[keyof typeof ESTIMATION_INPUT_MODES]

export interface EstimationQuestionOptions {
  inputMode: EstimationInputMode
  min: number
  max: number
  step: number
  margin: number
}

export type QuestionOptions = MultiQuestionOptions | EstimationQuestionOptions

export interface Player {
  id: string
  clientId: string
  connected: boolean
  username: string
  points: number
  streak: number
}

export interface Answer {
  playerId: string
  answerIds: number[]
  points: number
}

export type QuestionMediaType =
  (typeof MEDIA_TYPES)[keyof typeof MEDIA_TYPES] | undefined

export interface QuestionMedia {
  type?: QuestionMediaType
  url: string
}

export type UploadedMediaType =
  (typeof ACCEPTED_MEDIA_TYPES)[keyof typeof ACCEPTED_MEDIA_TYPES]["type"]

export interface UploadedMedia {
  name: string
  url: string
  type: UploadedMediaType
}

export type QuestionPlayMode = "quiz" | "survey"

export interface Question {
  type: QuestionType
  playMode?: QuestionPlayMode
  question: string
  category?: string
  note?: string
  media?: QuestionMedia
  answers: string[]
  solutions?: number[]
  cooldown: number
  time: number
  maxPoints?: number
  penalty?: number
  options?: QuestionOptions
}

export interface Quizz {
  gameMode: QuizzMode
  subject: string
  questions: Question[]
}

export type QuizzWithId = Quizz & { id: string }

export interface QuizzMeta {
  id: string
  subject: string
}

export interface AutoAdvanceSettings {
  enable: boolean
  responsesDelay: number
  leaderboardDelay: number
}

export interface GameSettings {
  generatedUsernames: boolean
  answersOnly: boolean
  phoneInviteOnly?: boolean
  endOnAllAnswered?: boolean
  autoAdvance: AutoAdvanceSettings
}

export interface GameUpdateQuestion {
  current: number
  total: number
}

export interface PlayerAnswerRecord {
  playerName: string
  answerIds: number[] | null
  correct?: boolean
  points?: number
}

export type QuestionResult = Question & {
  playerAnswers: PlayerAnswerRecord[]
  playerAnswersCount?: number
  skipped?: boolean
  skipReason?: string
}

export interface GameResultPlayer {
  username: string
  points: number
  rank: number
}

export interface GameResult {
  id: string
  gameMode: QuizzMode
  subject: string
  date: string
  players: GameResultPlayer[]
  questions: QuestionResult[]
}

export interface GameResultMeta {
  id: string
  gameMode: QuizzMode
  subject: string
  date: string
  playerCount: number
}
