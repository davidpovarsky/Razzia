import assert from "node:assert/strict"
import test from "node:test"
import { harness, show, newKey, data, code, principal, MemoryDrafts } from "./fixtures.ts"

test("real SDK initialize/discovery, strict schemas and three static resources", async () => {
  const h = await harness()
  try {
    const listing = await h.client.listTools()
    assert.equal(listing.tools.length, 8)
    const linked = listing.tools.filter((tool) => tool._meta?.ui &&
      typeof tool._meta.ui === "object" && "resourceUri" in tool._meta.ui)
    assert.deepEqual(linked.map((tool) => tool.name), ["preview_game"])
    for (const tool of listing.tools) {
      assert.equal(tool.inputSchema.additionalProperties, false)
      assert.ok(tool.outputSchema)
      assert.ok(tool._meta?.securitySchemes)
    }
    const resources = await h.client.listResources()
    assert.equal(resources.resources.length, 3)
    const resource = await h.client.readResource({ uri: "ui://tadazz/quiz-preview/v1.html" })
    assert.equal(resource.contents[0]?.mimeType, "text/html;profile=mcp-app")
    assert.equal(JSON.stringify(resource).includes(h.account.accountId), false)
  } finally { await h.close() }
})

test("validated same-draft content edit, CAS conflict, key replay and no read writes", async () => {
  const h = await harness()
  try {
    const authored = show()
    const key = newKey()
    const created = data(await h.call("create_game_draft", { authoredShowJson: JSON.stringify(authored), idempotencyKey: key }))
    const replay = data(await h.call("create_game_draft", { authoredShowJson: JSON.stringify(authored), idempotencyKey: key }))
    assert.equal(created.draftId, replay.draftId)
    assert.equal(h.store.records.size, 1)
    authored.cards[2]!.question = "Edited Q3"
    const result = await h.call("update_game_draft", {
      draftId: created.draftId, expectedRevision: 1, idempotencyKey: newKey(),
      authoredShowJson: JSON.stringify(authored),
    })
    assert.equal(data(result).revision, 2)
    const beforeReads = structuredClone(h.store.audit)
    const read = data(await h.call("get_game_draft", { draftId: created.draftId }))
    const normalized = JSON.parse(String(read.authoredShowJson))
    assert.equal(normalized.cards[2].question, "Edited Q3")
    assert.equal(normalized.cards[0].key, "q1")
    assert.equal(normalized.cards[0].question, "Question 1")
    assert.deepEqual(h.store.audit, beforeReads)
    assert.equal(code(await h.call("update_game_draft", {
      draftId: created.draftId, expectedRevision: 1, idempotencyKey: newKey(),
      authoredShowJson: JSON.stringify(authored),
    })), "REVISION_CONFLICT")
    assert.equal(code(await h.call("create_game_draft", {
      authoredShowJson: JSON.stringify(authored), idempotencyKey: key,
    })), "REQUEST_KEY_REUSED")
  } finally { await h.close() }
})

test("two real SDK sessions retain account isolation and revoked replay is denied", async () => {
  const shared = new MemoryDrafts()
  const a = await harness({ drafts: shared })
  const b = await harness({ drafts: shared })
  try {
    const key = newKey()
    const created = data(await a.call("create_game_draft", { authoredShowJson: JSON.stringify(show()), idempotencyKey: key }))
    assert.equal(code(await b.call("get_game_draft", { draftId: created.draftId })), "NOT_FOUND")
    a.account.expiresAt = 0
    assert.equal(code(await a.call("create_game_draft", {
      authoredShowJson: JSON.stringify(show()), idempotencyKey: key,
    })), "SCOPE_REQUIRED")
    assert.equal(shared.records.size, 1)
  } finally { await Promise.all([a.close(), b.close()]) }
})

for (const invalid of [
  { issuer: "https://attacker.example.invalid" }, { audience: "https://other.example.invalid" },
  { accountId: "" }, { active: false }, { accountsEnabled: false }, { expiresAt: 0 }, { scopes: [] },
]) {
  test("invalid principal fails before account store: " + Object.keys(invalid).join(), async () => {
    const h = await harness({ authorize: async () => ({ ...principal(), ...invalid }) })
    try {
      assert.equal(code(await h.call("create_game_draft", {
        authoredShowJson: JSON.stringify(show()), idempotencyKey: newKey(),
      })), "SCOPE_REQUIRED")
      assert.equal(h.store.records.size, 0)
    } finally { await h.close() }
  })
}

test("missing real authorizer/rate limiter/repository and preview/save/download fail closed", async () => {
  const h = await harness()
  const unauthed = await harness({ authorize: undefined })
  const noRate = await harness({ rateLimit: undefined })
  const noStore = await harness({ drafts: undefined })
  try {
    assert.equal(code(await unauthed.call("get_game_draft", { draftId: newKey() })), "ACCOUNT_UNAVAILABLE")
    assert.equal(code(await noRate.call("get_game_draft", { draftId: newKey() })), "DEPENDENCY_UNAVAILABLE")
    assert.equal(code(await noStore.call("get_game_draft", { draftId: newKey() })), "DEPENDENCY_UNAVAILABLE")
    const draft = data(await h.call("create_game_draft", { authoredShowJson: JSON.stringify(show()), idempotencyKey: newKey() }))
    const args = { draftId: draft.draftId, expectedRevision: 1, idempotencyKey: newKey() }
    assert.equal(code(await h.call("preview_game", { draftId: draft.draftId, expectedRevision: 1 })), "PREVIEW_UNAVAILABLE")
    assert.equal(code(await h.call("save_game", { ...args, intent: "createNew" })), "DEPENDENCY_UNAVAILABLE")
    assert.equal(code(await h.call("export_game", { ...args, format: "tada-json" })), "EXPORT_UNAVAILABLE")
    assert.equal(h.store.records.size, 1)
  } finally { await Promise.all([h.close(), unauthed.close(), noRate.close(), noStore.close()]) }
})

test("invalid authored/schema/settings/media rejected without mutation", async () => {
  const h = await harness()
  try {
    for (const raw of [
      "{}", '{"format":"tada-show","version":1}',
      JSON.stringify({ ...show(), settings: [{ scope: "show", property: "x", valueJson: {} }] }),
      JSON.stringify({ ...show(), cards: [{ ...show().cards[0], answers: [{ text: "A" }] }] }),
      JSON.stringify({ ...show(), defaults: { showTheme: { id: "foreign", version: "1.0.0" } } }),
      JSON.stringify({ ...show(), cards: [{ ...show().cards[0], media: { type: "image", url: "https://private.example.invalid/a.png" } }] }),
      " ".repeat(32769),
    ]) {
      const result = await h.call("create_game_draft", { authoredShowJson: raw, idempotencyKey: newKey() })
      assert.equal(result.isError, true)
    }
    assert.equal(h.store.records.size, 0)
  } finally { await h.close() }
})

test("scoped ordinary export delegates without adding a new consent stage", async () => {
  let exports = 0
  const h = await harness({ exports: { async createAuthorizedDownload(_p, draft, format) {
    exports++
    return { exportId: newKey(), draftId: draft.draftId, revision: draft.revision, format,
      downloadUrl: "https://studio.example.invalid/download/" + newKey(),
      expiresAt: new Date(Date.now() + 60_000).toISOString(), sha256: "a".repeat(64), bytes: 10 }
  } } })
  try {
    const draft = data(await h.call("create_game_draft", { authoredShowJson: JSON.stringify(show()), idempotencyKey: newKey() }))
    const result = await h.call("export_game", {
      draftId: draft.draftId, expectedRevision: 1, idempotencyKey: newKey(), format: "tada-json",
    })
    assert.notEqual(result.isError, true)
    assert.equal(data(result).format, "tada-json")
    assert.equal(exports, 1)
  } finally { await h.close() }
})

test("concurrent CAS produces one winner without silently replacing another revision", async () => {
  const h = await harness()
  try {
    const first = data(await h.call("create_game_draft", { authoredShowJson: JSON.stringify(show()), idempotencyKey: newKey() }))
    const args = { draftId: first.draftId, expectedRevision: 1, authoredShowJson: JSON.stringify(show()) }
    const results = await Promise.all([
      h.call("update_game_draft", { ...args, idempotencyKey: newKey() }),
      h.call("update_game_draft", { ...args, idempotencyKey: newKey() }),
    ])
    assert.equal(results.filter((r) => !r.isError).length, 1)
    assert.equal(code(results.find((r) => r.isError)!), "REVISION_CONFLICT")
  } finally { await h.close() }
})

test("rate denials and unexpected dependency failures expose no raw secret or mutation", async () => {
  const denied = await harness({ rateLimit: async () => false })
  const secret = "synthetic-secret-never-echo"
  const broken = await harness({ catalog: {
    async listTemplates() { throw new Error(secret) },
    async listThemes() { return { items: [] } },
  } })
  try {
    assert.equal(code(await denied.call("create_game_draft", {
      authoredShowJson: JSON.stringify(show()), idempotencyKey: newKey(),
    })), "RATE_LIMITED")
    assert.equal(denied.store.records.size, 0)
    const result = await broken.call("list_game_templates", {})
    assert.equal(code(result), "INTERNAL")
    assert.equal(JSON.stringify(result).includes(secret), false)
    assert.equal(JSON.stringify(result).includes(broken.account.accountId), false)
    const forged = await broken.call("get_game_draft", { draftId: newKey(), tenantId: broken.account.accountId })
    assert.equal(forged.isError, true)
  } finally { await Promise.all([denied.close(), broken.close()]) }
})

test("actual authoring answer bounds are preserved without a renderer-support claim", async () => {
  const h = await harness()
  try {
    for (const count of [0, 1, 2, 5, 6, 64]) {
      const authored = show()
      authored.cards[0]!.answers = Array.from({ length: count }, (_, i) => ({ text: "Option " + i }))
      const result = await h.call("create_game_draft", {
        authoredShowJson: JSON.stringify(authored), idempotencyKey: newKey(),
      })
      assert.equal(result.isError === true, count < 2 || count > 5, "answer count " + count)
    }
  } finally { await h.close() }
})
