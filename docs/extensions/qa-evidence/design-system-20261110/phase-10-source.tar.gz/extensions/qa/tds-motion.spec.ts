import { expect, test, type Page } from "@playwright/test"

type MotionWindow = Window & { __tdsMotionEvents: string[] }

async function recordAnimations(page: Page) {
  await page.addInitScript(() => {
    const win = window as MotionWindow
    win.__tdsMotionEvents = []
    document.addEventListener("animationstart", (event) => {
      win.__tdsMotionEvents.push(`start:${event.animationName}`)
    })
    document.addEventListener("animationend", (event) => {
      win.__tdsMotionEvents.push(`end:${event.animationName}`)
    })
    document.addEventListener("animationcancel", (event) => {
      win.__tdsMotionEvents.push(`cancel:${event.animationName}`)
    })
  })
}

async function events(page: Page) {
  return page.evaluate(() => (window as MotionWindow).__tdsMotionEvents)
}

test("scoped menus, popovers, dialogs, tabs, cards and feedback use token motion and survive interruption", async ({
  page,
}, testInfo) => {
  await recordAnimations(page)
  await page.goto("/")

  for (const name of ["host", "site"]) {
    const panel = page.getByTestId(`${name}-panel`)
    const menuTrigger = panel.getByRole("button", {
      name: `${name} actions`,
      exact: true,
    })
    await menuTrigger.click()
    const menu = page.getByRole("menu")
    await expect(menu).toHaveCSS("animation-name", "tds-menu-in")
    await expect(menu).toHaveCSS("animation-duration", "0.12s")
    await page.keyboard.press("Escape")
    await expect(menu).toHaveCount(0)
    await expect(menuTrigger).toBeFocused()

    const popoverTrigger = panel.getByRole("button", {
      name: `${name} open popover`,
      exact: true,
    })
    await popoverTrigger.click()
    const popover = page.getByLabel(`${name} popover`, { exact: true })
    await expect(popover).toHaveCSS("animation-name", "tds-menu-in")
    await page.keyboard.press("Escape")
    await expect(popoverTrigger).toBeFocused()

    const dialogTrigger = panel.getByRole("button", {
      name: `${name} open dialog`,
      exact: true,
    })
    for (let index = 0; index < 4; index += 1) {
      await dialogTrigger.click()
      const dialog = page.getByRole("dialog", {
        name: `${name} dialog`,
        exact: true,
      })
      await expect(dialog).toHaveCSS("animation-name", "tds-dialog-in")
      await expect(dialog).toHaveCSS("animation-duration", "0.18s")
      await page.keyboard.press("Escape")
      await expect(dialog).toHaveCount(0)
      await expect(dialogTrigger).toBeFocused()
    }

    const secondTab = panel.getByRole("tab", {
      name: `${name} second tab`,
      exact: true,
    })
    await secondTab.click()
    const tabPanel = panel.getByRole("tabpanel")
    await expect(tabPanel).toHaveCSS("animation-name", "tds-selection-in")
    await expect(tabPanel).toHaveCSS("animation-duration", "0.18s")
    await expect(panel.getByTestId(`${name}-message`)).toHaveCSS(
      "animation-name",
      "tds-feedback-in",
    )
    await expect(panel.getByTestId(`${name}-interactive-card`)).toHaveCSS(
      "transition-duration",
      "0.12s, 0.18s, 0.12s",
    )
  }

  await expect
    .poll(async () => (await events(page)).filter((name) => name.includes("tds-menu-out")).length)
    .toBeGreaterThanOrEqual(2)
  await expect
    .poll(async () => (await events(page)).filter((name) => name.includes("tds-dialog-out")).length)
    .toBeGreaterThanOrEqual(1)
  await page.screenshot({
    path: `/evidence/phase-10-motion-components-${testInfo.project.name}.png`,
    fullPage: true,
  })
})

test("reduced motion removes platform animation without changing keyboard state", async ({
  page,
}, testInfo) => {
  await page.emulateMedia({ reducedMotion: "reduce" })
  await recordAnimations(page)
  await page.goto("/")
  const panel = page.getByTestId("host-panel")

  const menuTrigger = panel.getByRole("button", {
    name: "host actions",
    exact: true,
  })
  await menuTrigger.focus()
  await page.keyboard.press("ArrowDown")
  const menu = page.getByRole("menu")
  await expect(menu).toHaveCSS("animation-name", "none")
  await page.keyboard.press("Escape")
  await expect(menuTrigger).toBeFocused()

  const dialogTrigger = panel.getByRole("button", {
    name: "host open dialog",
    exact: true,
  })
  await dialogTrigger.click()
  const dialog = page.getByRole("dialog", {
    name: "host dialog",
    exact: true,
  })
  await expect(dialog).toHaveCSS("animation-name", "none")
  await page.keyboard.press("Escape")
  await expect(dialogTrigger).toBeFocused()

  await panel.getByRole("tab", { name: "host second tab" }).click()
  await expect(panel.getByRole("tabpanel")).toHaveCSS("animation-name", "none")
  await expect(panel.getByTestId("host-message")).toHaveCSS(
    "animation-name",
    "none",
  )
  await expect(panel.getByTestId("host-interactive-card")).toHaveCSS(
    "transition-duration",
    "0.000001s",
  )
  expect(await events(page)).toEqual([])
  await page.screenshot({
    path: `/evidence/phase-10-motion-reduced-${testInfo.project.name}.png`,
    fullPage: true,
  })
})
