# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: qa-preview.spec.ts >> the five current-card phases render with zero synthetic voters
- Location: ../docs/extensions/qa-evidence/show-ui-20261115/qa-preview.spec.ts:61:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -   1
+ Received  + 110

- Array []
+ Array [
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+   Object {
+     "mime": "text/plain",
+     "path": "/tadazz-show/second-library/teaser-screen-source.jpg",
+     "sha256": "ba691ba042bcedd9a61a36f5969026bc95859dccdc7e47f24e6bce35673baf2f",
+     "status": 404,
+   },
+ ]
```

# Page snapshot

```yaml
- generic [ref=e5]:
  - generic:
    - img "Creating Worlds"
    - generic:
      - generic:
        - img "TADAZZ!"
      - generic: ROUND 01 · QUESTION 01 / 5
      - generic:
        - generic: AUDIENCE RESULTS
        - generic: Synthetic question 1
      - generic:
        - button "01" [disabled]:
          - article:
            - figure "Choice 1":
              - generic:
                - generic "Choice 1": "1"
            - generic: 0%
            - generic: CORRECT ANSWER
        - button "02" [disabled]:
          - article:
            - figure "Choice 2":
              - generic:
                - generic "Choice 2": "2"
            - generic: 0%
            - generic: AUDIENCE FAVOURITE
        - button "03" [disabled]:
          - article:
            - figure "Choice 3":
              - generic:
                - generic "Choice 3": "3"
            - generic: 0%
            - generic: AUDIENCE FAVOURITE
        - button "04" [disabled]:
          - article:
            - figure "Choice 4":
              - generic:
                - generic "Choice 4": "4"
            - generic: 0%
            - generic: AUDIENCE FAVOURITE
        - button "05" [disabled]:
          - article:
            - figure "Choice 5":
              - generic:
                - generic "Choice 5": "5"
            - generic: 0%
            - generic: AUDIENCE FAVOURITE
      - generic: AUDIENCE RESULTS
```

# Test source

```ts
  1   | import playwright from "../../../../node_modules/.pnpm/playwright@1.64.0/node_modules/playwright/test.js"
  2   | import type * as Playwright from "../../../../node_modules/.pnpm/playwright@1.64.0/node_modules/playwright/test.js"
  3   | import { request as httpRequest } from "node:http"
  4   | const { expect, test } = playwright as unknown as typeof Playwright
  5   | 
  6   | const events = new WeakMap<object, Array<Record<string, unknown>>>()
  7   | test.beforeEach(async ({ page }) => {
  8   |   const log: Array<Record<string, unknown>> = []
  9   |   events.set(page, log)
  10  |   page.on("console", (message) => { if (log.length < 2000) log.push({ type: "console", level: message.type(), text: message.text() }) })
  11  |   page.on("request", (request) => { if (log.length < 2000) log.push({ type: "request", url: request.url(), resourceType: request.resourceType() }) })
  12  |   page.on("requestfailed", (request) => { if (log.length < 2000) log.push({ type: "requestfailed", url: request.url(), error: request.failure()?.errorText }) })
  13  |   await page.addInitScript(() => {
  14  |     ;(window as any).__qaCsp = []
  15  |     window.addEventListener("securitypolicyviolation", (event) => { if ((window as any).__qaCsp.length < 2000) (window as any).__qaCsp.push({ directive: event.effectiveDirective, blocked: event.blockedURI }) })
  16  |   })
  17  | })
  18  | test.afterEach(async ({ page }, info) => {
  19  |   const csp = await page.evaluate(() => (window as any).__qaCsp ?? []).catch(() => [])
  20  |   const requests = await page.evaluate(async () => (await fetch("/qa/requests")).json()).catch(() => [])
  21  |   await info.attach("qa-browser-events.json", { body: Buffer.from(JSON.stringify({ events: events.get(page) ?? [], csp, requests }, null, 2)), contentType: "application/json" })
  22  | })
  23  | 
  24  | const locales = ["en", "fr", "de", "es", "it", "ja", "tr", "vi"] as const
  25  | for (const role of ["manager", "spectator"] as const) {
  26  |   for (const locale of locales) {
  27  |     test(`paused question and results: ${role}/${locale}`, async ({ page }) => {
  28  |       await page.goto("/")
  29  |       await expect(page.locator("html")).toHaveAttribute("data-qa-ready", "true")
  30  |       for (const phase of ["question", "results"] as const) {
  31  |         await page.evaluate(({ role, locale, phase }) => (window as any).__showPreviewQa.show({ role, locale, phase, paused: true, elapsed: phase === "results" ? 20000 : 5000 }), { role, locale, phase })
  32  |         await expect(page.getByTestId("tadazz-question-panel")).toContainText("Synthetic question 1")
  33  |         if (phase === "results") await expect(page.getByTestId("tadazz-card-0")).toBeVisible()
  34  |       }
  35  |       expect(await page.evaluate(() => (window as any).__showPreviewQa.failures())).toBe(0)
  36  |     })
  37  |   }
  38  | }
  39  | 
  40  | test("paused voting remains stable, resumes, and reuses the stage for q2", async ({ page }) => {
  41  |   test.setTimeout(60000)
  42  |   await page.goto("/")
  43  |   await expect(page.locator("html")).toHaveAttribute("data-qa-ready", "true")
  44  |   await page.evaluate(() => (window as any).__showPreviewQa.show({ phase: "voting", paused: true, elapsed: 5000 }))
  45  |   const timer = page.getByTestId("tadazz-timer").first()
  46  |   await expect(timer).toBeVisible()
  47  |   const before = await timer.textContent()
  48  |   await page.waitForTimeout(1200)
  49  |   expect(await timer.textContent()).toBe(before)
  50  |   await page.evaluate(() => {
  51  |     ;(window as any).__initialPreviewStage = (window as any).__showPreviewQa.stage()
  52  |     return (window as any).__showPreviewQa.show({ phase: "voting", paused: false, elapsed: 5000 })
  53  |   })
  54  |   await expect.poll(async () => timer.textContent(), { timeout: 5000 }).not.toBe(before)
  55  |   await page.evaluate(() => (window as any).__showPreviewQa.show({ phase: "question", question: 1, paused: false, elapsed: 6000 }))
  56  |   await expect(page.getByTestId("tadazz-question-panel")).toContainText("Synthetic question 2", { timeout: 15000 })
  57  |   expect(await page.evaluate(() => (window as any).__initialPreviewStage === (window as any).__showPreviewQa.stage())).toBe(true)
  58  |   expect(await page.evaluate(() => (window as any).__showPreviewQa.failures())).toBe(0)
  59  | })
  60  | 
  61  | test("the five current-card phases render with zero synthetic voters", async ({ page }, info) => {
  62  |   test.setTimeout(60000)
  63  |   await page.goto("/")
  64  |   await expect(page.locator("html")).toHaveAttribute("data-qa-ready", "true")
  65  |   await page.evaluate(() => { (window as any).__qaSfx = 0; window.addEventListener("tadazz:sfx", () => { (window as any).__qaSfx += 1 }) })
  66  |   const decoded = await page.evaluate(async () => {
  67  |     const paths = ["/tadazz-show/motion/backdrop.webp", "/tadazz-show/v4/question-bg.webp", "/tadazz-show/v4/show-stage.webp", "/tadazz-show/story/84acdb923677d591.webp", "/tadazz-show/v4/tadazz-brand-logo.png"]
  68  |     return Promise.all(paths.map(async (path) => {
  69  |       const response = await fetch(path)
  70  |       if (!response.ok) throw new Error(`decode fetch ${response.status}: ${path}`)
  71  |       const blob = await response.blob(), image = await createImageBitmap(blob)
  72  |       const result = { path, mime: blob.type, bytes: blob.size, width: image.width, height: image.height }
  73  |       image.close()
  74  |       return result
  75  |     }))
  76  |   })
  77  |   expect(decoded.map((image) => [image.width, image.height])).toEqual([[1920,1080],[1920,1080],[1920,1080],[1920,1080],[1983,793]])
  78  |   await info.attach("qa-decoded-images.json", { body: Buffer.from(JSON.stringify(decoded, null, 2)), contentType: "application/json" })
  79  |   await page.evaluate(() => (window as any).__showPreviewQa.show({ phase: "question", paused: false }))
  80  |   await expect(page.getByTestId("tadazz-question-panel")).toContainText("Synthetic question 1")
  81  |   await page.evaluate(() => (window as any).__showPreviewQa.show({ phase: "answerCards", paused: false }))
  82  |   await expect(page.getByTestId("tadazz-card-0")).toBeVisible()
  83  |   await page.evaluate(() => (window as any).__showPreviewQa.show({ phase: "voting", paused: false }))
  84  |   await expect(page.getByTestId("tadazz-timer").first()).toBeVisible()
  85  |   await page.evaluate(() => (window as any).__showPreviewQa.show({ phase: "voteLocked", paused: false, elapsed: 20000 }))
  86  |   await expect(page.getByTestId("tadazz-status").first()).toContainText(/locked/i)
  87  |   await page.evaluate(() => (window as any).__showPreviewQa.show({ phase: "results", paused: false, elapsed: 20000 }))
  88  |   await expect(page.getByTestId("tadazz-card-0")).toBeVisible()
  89  |   expect(await page.evaluate(() => (window as any).__showPreviewQa.failures())).toBe(0)
  90  |   expect(await page.evaluate(() => (window as any).__qaSfx)).toBe(0)
  91  |   const requests = await page.evaluate(async () => (await fetch("/qa/requests")).json())
> 92  |   expect(requests.filter((entry: { status: number }) => entry.status !== 200)).toEqual([])
      |                                                                                ^ Error: expect(received).toEqual(expected) // deep equality
  93  | })
  94  | 
  95  | for (const phase of ["answerCards", "voteLocked"] as const) {
  96  |   test(`initial paused ${phase} renders current card`, async ({ page }) => {
  97  |     await page.goto("/")
  98  |     await expect(page.locator("html")).toHaveAttribute("data-qa-ready", "true")
  99  |     await page.evaluate((phase) => (window as any).__showPreviewQa.show({ phase, paused: true }), phase)
  100 |     await expect(page.getByTestId("tadazz-question-panel")).toContainText("Synthetic question 1")
  101 |     await expect(page.getByTestId("tadazz-card-0")).toBeVisible()
  102 |   })
  103 | }
  104 | 
  105 | test("pause during voting entry and supersede a lock with q2", async ({ page }) => {
  106 |   test.setTimeout(60000)
  107 |   await page.goto("/")
  108 |   await expect(page.locator("html")).toHaveAttribute("data-qa-ready", "true")
  109 |   await page.evaluate(async () => {
  110 |     await (window as any).__showPreviewQa.show({ phase: "voting", paused: false, elapsed: 5000 })
  111 |     await (window as any).__showPreviewQa.show({ phase: "voting", paused: true, elapsed: 5000 })
  112 |   })
  113 |   const timer = page.getByTestId("tadazz-timer").first()
  114 |   await expect(timer).toBeVisible()
  115 |   const stopped = await timer.textContent()
  116 |   await page.waitForTimeout(1200)
  117 |   expect(await timer.textContent()).toBe(stopped)
  118 |   await page.evaluate(async () => {
  119 |     await (window as any).__showPreviewQa.show({ phase: "voteLocked", paused: false, elapsed: 20000 })
  120 |     await (window as any).__showPreviewQa.show({ phase: "question", question: 1, paused: false, elapsed: 6000 })
  121 |   })
  122 |   await expect(page.getByTestId("tadazz-question-panel")).toContainText("Synthetic question 2", { timeout: 15000 })
  123 |   await page.waitForTimeout(500)
  124 |   await expect(page.getByTestId("tadazz-question-panel")).toContainText("Synthetic question 2")
  125 |   expect(await page.evaluate(() => (window as any).__showPreviewQa.failures())).toBe(0)
  126 | })
  127 | 
  128 | test("browser rejects mismatched script and style integrity", async ({ page }) => {
  129 |   await page.goto("/")
  130 |   await expect(page.locator("html")).toHaveAttribute("data-qa-ready", "true")
  131 |   const result = await page.evaluate(async () => {
  132 |     const config = await (await fetch("/qa/config")).json()
  133 |     const check = (element: HTMLScriptElement | HTMLLinkElement, parent: HTMLElement | ShadowRoot) => new Promise<boolean>((resolve) => {
  134 |       element.onload = () => resolve(false)
  135 |       element.onerror = () => resolve(true)
  136 |       parent.append(element)
  137 |     })
  138 |     const script = document.createElement("script")
  139 |     script.type = "module"; script.src = "/qa/integrity-decoy.js"; script.integrity = config.jsIntegrity; script.crossOrigin = "anonymous"
  140 |     const link = document.createElement("link")
  141 |     link.rel = "stylesheet"; link.href = "/qa/integrity-decoy.css"; link.integrity = config.cssIntegrity; link.crossOrigin = "anonymous"
  142 |     return Promise.all([check(script, document.head), check(link, (window as any).__showPreviewQa.shadow())])
  143 |   })
  144 |   expect(result).toEqual([true, true])
  145 | })
  146 | 
  147 | test("fixture denies normalized or encoded native paths", async () => {
  148 |   const address = new URL(process.env.TADAZZ_QA_BASE ?? "")
  149 |   const get = (path: string) => new Promise<number>((resolve, reject) => {
  150 |     const req = httpRequest({ hostname: "127.0.0.1", port: Number(address.port), path, method: "GET" }, (res) => { res.resume(); resolve(res.statusCode ?? 0) })
  151 |     req.on("error", reject)
  152 |     req.end()
  153 |   })
  154 |   expect(await get("/tadazz-show/v4/../v4/question-bg.webp")).toBe(400)
  155 |   expect(await get("/tadazz-show/v4/%71uestion-bg.webp")).toBe(400)
  156 |   expect(await get("/tadazz-show/v4/question-bg.webp?alternate=1")).toBe(404)
  157 | })
  158 | 
```